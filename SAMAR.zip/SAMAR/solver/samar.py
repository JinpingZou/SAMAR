import math
import torch
import torch.optim

from utils.configurable import configurable

from solver.build import OPTIMIZER_REGISTRY


@OPTIMIZER_REGISTRY.register()
class SAMAR(torch.optim.Optimizer):
    @configurable()
    def __init__(self,params,base_optimizer,rho,lamb,alpha,chi,delta) -> None:
        assert isinstance(base_optimizer, torch.optim.Optimizer), f"base_optimizer must be an `Optimizer`"
        self.base_optimizer = base_optimizer

        assert 0 <= rho, f"rho should be non-negative:{rho}"
        self.rho = rho
        self.lamb=lamb
        self.alpha=alpha
        self.chi=chi
        self.delta=delta
        self.oldGradNorm=1e-7
        self.curGradNorm=0
        super(SAMAR, self).__init__(params, dict(rho=rho))
        self.param_groups = self.base_optimizer.param_groups
        self.lamblist=[]
        self.ratiolist=[]

        for group in self.param_groups:
            group["rho"] = rho
        

    def updateLamb(self):
        ratio=self.curGradNorm/self.oldGradNorm
        self.ratiolist.append(ratio)
        if ratio<self.chi:
            proj=self.lamb/self.alpha
            if proj>=1-self.delta:
                self.lamb=1-self.delta
            elif proj<=self.delta:
                proj=self.delta
            else:
                self.lamb=proj
        else:
            proj=self.lamb*self.alpha
            if proj>=1-self.delta:
                self.lamb=1-self.delta
            elif proj<=self.delta:
                proj=self.delta
            else:
                self.lamb=proj
        self.lamblist.append(self.lamb)

    def setoldGradNorm(self,oldGradNorm=1e-7):
        self.oldGradNorm=oldGradNorm

    def setcurGradNorm(self):
        self.curGradNorm=self._grad_norm()

    def getLamb(self):
        return self.lamb

    @classmethod
    def from_config(cls, args):
        return {
            "rho": args.rho,
            "lamb":args.lamb,
            "alpha":args.alpha,
            "chi":args.chi,
            "delta":args.delta
        }
    
    @torch.no_grad()
    def first_step(self, zero_grad=False):
        grad_norm = self._grad_norm()   #get ||▽f(w)||
        for group in self.param_groups:
            scale=group["rho"]/(grad_norm+1e-7)#get ρ/ ||▽f(w)||
            for p in group["params"]:
                if p.grad is None: continue 
                e_w = p.grad * scale
                p.add_(e_w) 
                self.state[p]["e_w"] = e_w
                self.state[p]["w_grad"]=p.grad
        if zero_grad: self.zero_grad()
    #achieve w+e(w),change model's weight from w to w+e(w)
    
    @torch.no_grad()
    def second_step(self, zero_grad=False):
        self.setcurGradNorm()
        for group in self.param_groups:
            for p in group["params"]:
                if p.grad is None: continue
                p.grad=(1-self.lamb)*self.state[p]['w_grad']+self.lamb*p.grad
                p.sub_(self.state[p]["e_w"])  # get back to "w" from "w + e(w)"
        self.base_optimizer.step()  #w=w-lr*▽f(w+e(w))
        if zero_grad: self.zero_grad()

    @torch.no_grad()
    def step(self, closure=None, **kwargs):
        assert closure is not None, "SAMAR requires closure, which is not provided."
        
        self.first_step(True)
        with torch.enable_grad():
            closure()   #calculate loss=f(w+e(w))
                        #loss.backwrd():▽f(w+e(w))
        getGradNorm=self._grad_norm()
        self.second_step()
        return getGradNorm

    def _grad_norm(self):
        shared_device = self.param_groups[0]["params"][0].device  # put everything on the same device, in case of model parallelism
        norm = torch.norm(
                    torch.stack([
                        p.grad.norm(p=2).to(shared_device)
                        for group in self.param_groups for p in group["params"]
                        if p.grad is not None
                    ]),
                    p=2
               )
        return norm

